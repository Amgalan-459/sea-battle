﻿using System.Text;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Controls.Primitives;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using System.Net;
using System.Net.Sockets;
using System.Text.Json.Serialization;
using Newtonsoft.Json;
using System.IO;
using System.Runtime.CompilerServices;
using TCPLib;
using server;
using Prism;

namespace NpExam
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        private IList<ShipCoordinates> playerCoordinates = new List<ShipCoordinates>();
        private const int BoardSize = 10; // Размер поля
        private Button[,] gridButtons, evilGridButtons; // Двумерный массив кнопок для отображения поля
        private TcpClient server;
        private int available_ships = (BoardSize * BoardSize) / 5; //доступное количество кораблей

        public MainWindow()
        {
            InitializeComponent();
            InitializeGameGrid();
            InitializeEvilGameGrid();
            playerCoordinates = new List<ShipCoordinates>();
            server = new TcpClient("10.211.55.3", 2024);
            playersGrid.IsEnabled = false;
            readyPanel.IsEnabled = false;
            ship_counter.Text = available_ships.ToString(); //крепим текст к счетчику
        }

        private void InitializeGameGrid() //создаем поле игрока
        {
            gridButtons = new Button[BoardSize, BoardSize];

            for (int i = 0; i < BoardSize; i++)
            {
                for (int j = 0; j < BoardSize; j++)
                {
                    Button button = new Button
                    {
                        Width = 30,
                        Height = 30,
                        Margin = new Thickness(1),
                        Background = Brushes.Cyan
                    };

                    button.Click += Cell_Click;

                    ShipUniformGrid.Children.Add(button);

                    Grid.SetRow(button, i);
                    Grid.SetColumn(button, j);

                    gridButtons[i, j] = button;
                }
            }
        }

        private void InitializeEvilGameGrid() //создаем вражеское поле
        {
            evilGridButtons = new Button[BoardSize, BoardSize];

            for (int i = 0; i < BoardSize; i++)
            {
                for (int j = 0; j < BoardSize; j++)
                {
                    Button button = new Button
                    {
                        Width = 30,
                        Height = 30,
                        Margin = new Thickness(1),
                        Background = Brushes.Cyan
                    };

                    button.Click += EvilCell_Click;

                    EvilShipUnifromGrid.Children.Add(button);

                    Grid.SetRow(button, i);
                    Grid.SetColumn(button, j);

                    evilGridButtons[i, j] = button;
                }
            }
        }

        private void Cell_Click(object sender, RoutedEventArgs e) //нажатие на клетку игрока
        {
            Button clickedButton = (Button)sender;
            int row = (int)clickedButton.GetValue(Grid.RowProperty);
            int column = (int)clickedButton.GetValue(Grid.ColumnProperty);

            if (available_ships == 0 && gridButtons[row, column].Background != Brushes.Gray) //если кораблей уже 20, то ошибка
            {
                MessageBox.Show("Вы превысили допустимый лимит кораблей!", "Ошибка!", MessageBoxButton.OK, MessageBoxImage.Error);
            }
            else
            {
                // Проверяем, выбран ли режим расстановки кораблей
                if (readyCheckBox.IsChecked == false)
                {
                    if (gridButtons[row,column].Background == Brushes.Gray 
                        && gridButtons[row, column].Content != null) //если там стоит нос, то удаляем
                    {
                        DeleteShipInCell(row, column);
                    }
                    else if (gridButtons[row, column].Background == Brushes.Gray) //если корабль, то ставим нос
                    {
                        SetShipInCell(row, column, true);
                    }
                    else
                    {
                        List<ShipCoordinates> temp = [.. playerCoordinates]; 
                        if (CheckShips(row, column, temp)) //если там пусто, то проверяем на наличие носа в ближайших клетках
                        {
                            SetShipInCell(row, column, false);
                            available_ships--;
                            ship_counter.Text = available_ships.ToString();
                            playerCoordinates.Add(new(row, column ));
                        }
                        else
                        {
                            MessageBox.Show("Вы не можете ставить корабли рядом!", "Ошибка!", MessageBoxButton.OK, MessageBoxImage.Error);
                        }
                    }
                }
                else
                {
                    MessageBox.Show("Вы уже готовы к игре! Если хотите вернуться к расстановке кораблей, то уберите галочку.");
                }
            }
        }

        private void SetShipInCell(int row, int column, bool is_nose)
        { 
            gridButtons[row, column].Background = Brushes.Gray;
            if(is_nose)
            {
                gridButtons[row, column].Content = "+";
                gridButtons[row, column].Foreground = Brushes.White;
            }
        }



        private void DeleteShipInCell(int row, int column)
        {
            gridButtons[row, column].Background = Brushes.Cyan;
            gridButtons[row, column].Content = null;
            playerCoordinates.Remove(new(row,column));
            available_ships++;
            ship_counter.Text = available_ships.ToString();
        }

        private bool CheckShips(int row, int column, List<ShipCoordinates> coords) //проверка на валидность клетки
        {
            for (int i = row - 1; i <= row + 1; i++)
            {
                for (int j = column - 1; j <= column + 1; j++)
                {
                    if (i >= 0 && i < BoardSize && j >= 0 && j < BoardSize)
                    {
                        if (coords.Contains(new(i, j)) && gridButtons[i,j].Content == null) //если в клетке есть корабль, то рекурсивно обходим все клетки пока не найдем нос
                        {
                            coords.Remove(new(i, j));
                            CheckShips(i, j, coords);
                        }
                        else if (coords.Contains(new(i,j)) && gridButtons[i,j].Content != null) //если нашли, то там поставить корабль нельзя
                        {
                            return false;
                        }
                    }
                }
            }

            return true;
        }

        private async void EvilCell_Click(object sender, RoutedEventArgs e) //нажатие на клетку врага
        {
            Button clickedButton = (Button)sender;
            int row = (int)clickedButton.GetValue(Grid.RowProperty);
            int column = (int)clickedButton.GetValue(Grid.ColumnProperty);

                await EvilSetShipInCell(row, column); //выстрел во врага
                clickedButton.Click -= EvilCell_Click; //на эту кнопку больше не нажмет клиент - отписываемся
        }


        private async Task EvilSetShipInCell(int row, int column)
        {
            await TCP.SendInt(server, row);
            await TCP.SendInt(server, column);

            int isHit = await TCP.ReceiveInt(server); //если промах, то там звездочка
            if (isHit == (int)StateEnum.Miss)
            {
                evilGridButtons[row, column].Content = "*";
            }
            else if (isHit == (int)StateEnum.Hit)
            {
                evilGridButtons[row, column].Content = "X"; //если попали, то там Х и клетка закрашивается красным
                evilGridButtons[row, column].Background = Brushes.Red;
                evilGridButtons[row, column].Foreground = Brushes.White;
            }
            EvilShipUnifromGrid.IsEnabled = false; //выключаем поле пока не будет наш ход
            await TCP.SendInt(server, 1); //мы сделали ход
            await GameStatusCheck(); //ждем статуса игры
        }

        private async void ReceiveFire() //вызывается когда не наш ход
        {
            int status = await TCP.ReceiveInt(server);
            int row = await TCP.ReceiveInt(server);
            int column = await TCP.ReceiveInt(server);

            if(status == (int)StateEnum.Miss) //по нам промазали? там стоит тогда *
            {
                gridButtons[row, column].Content = "*";
            }
            else
            {
                gridButtons[row, column].Content = "X"; //попали? наша клетка подорвана
                gridButtons[row, column].Background = Brushes.Red;
            }
            await TCP.SendInt(server, 1); //мы сделали ход
            await GameStatusCheck(); //ждем статуса игры
        }

        private string SerializeCoordinates(List<ShipCoordinates> coordinates) //сериализуем и отправляем наши координаты
        {
            string text = System.Text.Json.JsonSerializer.Serialize(coordinates);
            //File.WriteAllTextAsync($"{regTextBox.Text}_coords.json", text);
            //return $"{regTextBox.Text}_coords.json";
            return text;
        }

        private async void readyCheckBox_Checked(object sender, RoutedEventArgs e) //мы готовы?
        {
            if(available_ships != 0) //если не поставили все корабли, то не готовы
            {
                MessageBox.Show("Вы расставили недостаточно кораблей!");
                readyCheckBox.IsChecked = false;
            }
            else
            {
                readyCheckBox.IsChecked = true;
                await TCP.SendInt(server, 1); //мы готовы!
                    int status = await TCP.ReceiveInt(server); //получаем статус игры
                    if (status == (int)GameState.Start)
                    {
                    // Отправка координат кораблей на сервер и переход в фазу боя
                    //FileInfo file = new FileInfo(SerializeCoordinates(playerCoordinates.ToList()));
                    //await TCP.SendLong(server, file.Length);
                    //using Stream file_stream = File.OpenRead(file.Name);
                    //await TCP.SendFile(server, file_stream, file.Length);
                        await TCP.SendString(server, SerializeCoordinates(playerCoordinates.ToList()));
                        await GameStatusCheck();
                    }
                readyCheckBox.Visibility = Visibility.Hidden;
                
            }
        }

        private async void RegistrationButton_Click(object sender, RoutedEventArgs e)
        {
            if (string.IsNullOrEmpty(regTextBox.Text))
            {
                MessageBox.Show("Введите имя!", "Ошибка", MessageBoxButton.OK, MessageBoxImage.Error);
                return;
            }

            await TCP.SendString(server, regTextBox.Text);

            regPanel.Visibility = Visibility.Hidden;
            MessageBox.Show("Регистрация завершена", "Успех", MessageBoxButton.OK, MessageBoxImage.Information);

            readyPanel.IsEnabled = true;
            playersGrid.IsEnabled = true;
        }

        //private async void PlayButton_Click(object sender, RoutedEventArgs e)
        //{
        //    if (readyCheckBox.IsChecked == true)
        //    {
        //        await TCP.SendInt(server, 1);
        //        int status = await TCP.ReceiveInt(server);
        //        if(status == (int)GameState.Start)
        //        {
        //            // Отправка координат кораблей на сервер и переход в фазу боя
        //            FileInfo file = new FileInfo(SerializeCoordinates(playerCoordinates));
        //            await TCP.SendLong(server, file.Length);
        //            using Stream file_stream = File.OpenRead(file.Name);
        //            await TCP.SendFile(server, file_stream, file.Length);
        //            await GameStatusCheck();
        //        }
        //    }
        //    else
        //    {
        //        MessageBox.Show("Вы не отметили, что вы готовы!");
        //    }
        //}

        private async Task GameStatusCheck() //проверка на статус игры
        {
            try
            {
                int game_status = await TCP.ReceiveInt(server); //получаем статус
                if (game_status == (int)GameState.Ongoing) //игра идет? тогда 
                {
                    bool is_my_turn = ConvertToBool(await TCP.ReceiveInt(server)); //наш ход?
                    if (is_my_turn) //получаем возможность стрелять в противника
                    {
                        MessageBox.Show("Ваш ход!");
                        EvilShipUnifromGrid.IsEnabled = true;
                    }
                    else //сами находимся под обстрелом
                    {
                        ReceiveFire();
                    }
                }
                else if (game_status == (int)GameState.Won)
                {//мы выиграли?
                    MessageBox.Show("Вы выиграли!", "Ура!", MessageBoxButton.OK, MessageBoxImage.Exclamation); //сообщение о победе
                    server.Close();
                    server.Dispose();
                    Application.Current.Shutdown(); //отключаемся от сервера и сами себя выключаем
                }
                else if (game_status == (int)GameState.Lost) //проиграли?
                {
                    MessageBox.Show("Вы проиграли!", "О нет!", MessageBoxButton.OK, MessageBoxImage.Exclamation); //сообщение о проигрыше
                    server.Close();
                    server.Dispose();
                    Application.Current.Shutdown(); //отключаемся от сервера и сами себя выключаем
                }
            
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

        bool ConvertToBool(int val) => val == 1;
    }
}