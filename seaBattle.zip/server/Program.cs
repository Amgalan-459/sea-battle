﻿using server;
using System.Drawing;
using System.Linq.Expressions;
using System.Net;
using System.Net.Sockets;
using System.Reflection;
using System.Reflection.Metadata.Ecma335;
using System.Text;
using System.Text.Json;
using TCPLib;
using static System.Net.Mime.MediaTypeNames;

IList<TcpClient> clients = new List<TcpClient>();

string ipaddress = "10.211.55.3";
const int Port = 2024;

int current_player = 0;
const int boardSize = 10;

IList<ShipCoordinates> player1_coords = new List<ShipCoordinates>();
IList<ShipCoordinates> player2_coords = new List<ShipCoordinates>();

TcpListener listener = new(new IPEndPoint(IPAddress.Parse(ipaddress), Port));
listener.Start();

Console.WriteLine($"Waiting for a connection at port 2024");

while (clients.Count <= 2)
{
    TcpClient client = await listener.AcceptTcpClientAsync();
    lock (clients)
        clients.Add(client);
    ListenToClient(client);
    
}

async void ListenToClient(TcpClient client)
{
    Console.WriteLine($"{client.Client.RemoteEndPoint} {DateTime.Now}");

    //булевый флаг - игрок готов или нет?
    bool is_player_ready = false;
    //имя игрока
    string player_name = "";
    //лист с координатами игрока
    IList<ShipCoordinates> player_coords = new List<ShipCoordinates>();
    //лист с координатами врага
    IList<ShipCoordinates> enemy_coords = new List<ShipCoordinates>();

    //int[,] player_states = new int[boardSize, boardSize];
    //int[,] enemy_states = new int[boardSize, boardSize];

    //FillStates(player_states);
    //FillStates(enemy_states);

    while (true)
    {
        try
        {
            //получаем имя игрока
            player_name = await TCP.ReceiveString(client);
            await Console.Out.WriteLineAsync($"Получено имя игрока: {player_name}");
        }
        catch (Exception e)
        {
            await Console.Out.WriteLineAsync(e.Message);
        }

        //делаем копию клиентов чтобы безопасно с ними работать
        IReadOnlyList<TcpClient> copy;

        lock (clients)
            copy = clients.ToList();
        is_player_ready = ConvertToBool(await TCP.ReceiveInt(client));
        //наш клиент готов?
        if (is_player_ready)
        {
            await Console.Out.WriteLineAsync($"Игрок {player_name} готов!");
        }
        else
        {
            //иначе ждем получения положительного значения (изначальнo false)
            try
            {
                is_player_ready = ConvertToBool(await TCP.ReceiveInt(client));
            }
            catch(Exception e)
            {
                await Console.Out.WriteLineAsync(e.Message);
            }
        }

        await TCP.SendInt(client, (int)GameState.Start);
        //получаем координаты игрока функцией ReceiveCoordinates()
        player_coords = await ReceiveCoordinates(client, $"{player_name}_coords.json");
        //если первый клиент - это наши координаты
        if (copy[0] == client)
        {
            lock (player1_coords)
                player1_coords = player_coords.ToList();
        }
        //и наоборот
        else
        {
            lock (player2_coords)
                player2_coords = player_coords.ToList();
        }
        await Console.Out.WriteLineAsync($"Успешно получены координаты игрока {player_name}!");
        //ждем пока не будут координаты ВСЕХ
        if (copy[0] == client)
        {
            while(true)
            {
                if(player2_coords.Count > 0)
                {
                    lock (player2_coords)
                        enemy_coords = player2_coords.ToList();
                    break;
                }
            }
        }
        else
        {
            while (true)
            {
                if(player1_coords.Count > 0)
                {

                    lock (player1_coords)
                    {
                        enemy_coords = player1_coords.ToList();
                    }
                    break;
                }
            }
        }
        //enemy_coords = await GetEnemyCoordinates(player_name, enemy_states);
        //IList<ShipCoordinates> temp = new List<ShipCoordinates>();

        //клиент сделал свой ход или нет?
        bool awaitingConfirmation = false;

        //пока вражеские корабли не закончатся
        while (enemy_coords.Count > 0)
        {
            //Игра началась!
            await TCP.SendInt(client, (int)GameState.Ongoing);
            //Этот клиент - не текущий игрок? Значит ждет
            if (client != copy[current_player])
            {
                await TCP.SendInt(client, 0);
                //Ждем действий от клиента
                awaitingConfirmation = true;
            }
            else
            {
                //Наш ход!
                await TCP.SendInt(client, 1);

                await Console.Out.WriteLineAsync($"Ход клиента {player_name}");
                //Получаем координаты от клиента
                ShipCoordinates received_coords = new(await TCP.ReceiveInt(client), await TCP.ReceiveInt(client));
                //Если есть в листе из вражеских координатов, то попали!
                if (enemy_coords.Contains(received_coords))
                {
                    //enemy_states[received_coords.X, received_coords.Y] = (int)StateEnum.Hit;
                    await Console.Out.WriteLineAsync($"Клиент {player_name} попал!");
                    //Отправляем врагу, что в него попали и координаты
                    foreach (TcpClient client_ in copy)
                    {
                        if (client_ != client)
                        {
                            await TCP.SendInt(client_, (int)StateEnum.Hit);
                            await TCP.SendInt(client_, received_coords.X);
                            await TCP.SendInt(client_, received_coords.Y);
                        }
                        //Себе отправляем, что попали
                        else
                        {
                            await TCP.SendInt(client_, (int)StateEnum.Hit);
                        }
                    }
                    //Удаляем эти координаты из списка
                    enemy_coords.Remove(received_coords);
                    //Ждем подтверждения
                    awaitingConfirmation = true;
                }
                else
                {
                    //Промазали? Отправляем всем, что промазали и координаты
                    await Console.Out.WriteLineAsync($"Клиент {player_name} промазал!");

                    foreach (TcpClient client_ in copy)
                    {
                        if (client_ != client)
                        {
                            await TCP.SendInt(client_, (int)StateEnum.Miss);
                            await TCP.SendInt(client_, received_coords.X);
                            await TCP.SendInt(client_, received_coords.Y);
                        }
                        else
                        {
                            await TCP.SendInt(client_, (int)StateEnum.Miss);
                        }
                    }
                    //Ход переходит врагу
                    for(int i = 0; i < copy.Count; i++)
                    {
                        if (copy[i] != client)
                        {
                            current_player = i;
                        }
                    }
                    //Ждем подтверждения
                    awaitingConfirmation = true;
                }
            }

            // Дождемся подтверждения от клиента перед переходом к следующему шагу
            while (awaitingConfirmation)
            {
                int confirmation = await TCP.ReceiveInt(client);
                if (confirmation == 1)
                {
                    awaitingConfirmation = false;
                }
            }

        }

        // Отправка результатов игры
        foreach (TcpClient client_ in copy)
        {
            if (client_ == client)
            {
                await TCP.SendInt(client_, (int)GameState.Won);
            }
            else
            {
                await TCP.SendInt(client_, (int)GameState.Lost);
            }
        }
    }

    client.Dispose();
    lock (clients)
        clients.Remove(client);
}

//простой конвертер в бул
bool ConvertToBool(int val) => val == 1;


//самодельная функция получения координат
//async Task<List<ShipCoordinates>> ReceiveCoordinates(TcpClient client, string file_name, int[,] states)
//{
//    try
//    {
//        //получаем длину файла с координатами и сам файл
//        await Console.Out.WriteLineAsync("Получаем координаты игрока");
//        long length = await TCP.ReceiveLong(client);
//        using Stream file = File.OpenWrite(file_name);
//        await TCP.ReceiveFile(client, file, length);
//    }
//    catch(Exception e)
//    {
//        await Console.Out.WriteLineAsync(e.Message);
//    }

//    //зачитываем содержимое файла и десериализуем
//    string content = await File.ReadAllTextAsync(file_name);
//    List<ShipCoordinates> list = JsonSerializer.Deserialize<List<ShipCoordinates>>(content)!; //точно не null!

//    //записываем в массив клеток корабли
//    for (int i = 0; i < list.Count; i++)
//    {
//        states[list[i].X, list[i].Y] = (int)StateEnum.Ship;
//    }
//    //расставляем воду в местах, где не стоят корабли
//    //for (int i = 0; i < 10; i++)
//    //{
//    //    for(int j = 0; j < 10; j++)
//    //    {
//    //        if (states[i,j] != (int) StateEnum.Ship)
//    //        {
//    //            states[i, j] = (int)StateEnum.Water;
//    //        }
//    //    }
//    //}


//    //возвращаем лист с координатами
//    return list;
//}

async Task<List<ShipCoordinates>> ReceiveCoordinates(TcpClient client, string file_name)
{
    string content = "";
    try
    {
        //получаем длину файла с координатами и сам файл
        //await Console.Out.WriteLineAsync("Получаем координаты игрока");
        //long length = await TCP.ReceiveLong(client);
        //using Stream file = File.OpenWrite(file_name);
        //await TCP.ReceiveFile(client, file, length);
        content = await TCP.ReceiveString(client);
    }
    catch (Exception e)
    {
        await Console.Out.WriteLineAsync(e.Message);
    }

    //зачитываем содержимое файла и десериализуем
    //string content = await File.ReadAllTextAsync(file_name);
    List<ShipCoordinates> list = JsonSerializer.Deserialize<List<ShipCoordinates>>(content)!; //точно не null!

    //возвращаем лист с координатами
    return list;
}

//void FillStates(int[,] arr)
//{
//    for(int i = 0; i < 10; i++)
//    {
//        for(int j = 0; j < 10; j++)
//        {
//            arr.SetValue((int)StateEnum.Water, i, j);
//        }
//    }
//}

